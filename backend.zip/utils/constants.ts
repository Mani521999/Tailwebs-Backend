export const STATES = {
    DRAFT: "Draft",
    PUBLISHED: "Published",
    COMPLETED: "Completed"
};